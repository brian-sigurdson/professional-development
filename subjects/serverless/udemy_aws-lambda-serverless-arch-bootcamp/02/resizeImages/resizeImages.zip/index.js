const im = require('imagemagick');
const fs = require('fs');
const os = require('os');
const uuidv4 = require('uuid/v4');
const {promisify} = require('util');
const AWS = require('aws-sdk');

AWS.config.update({ region: 'us-east-1'});
const s3 = new AWS.s3();

const resizeAsync = promisify(im.resize);
const readFileAsync = promisify(fs.readFile);
const unlinkAsync = promisify(fs.unlink);

exports.handler = async (event) => {
   let filesProcessed = event.Records.map( async (record) => {
        let bucket_name = record.s3.bucket.name;
        let filename = recored.s3.object.key;

        // get from s3
        var params = {
            Bucket: bucket,
            Key: filename
        };
        let inputData = await s3.getObject(params).promise();

        // resize the file
        let tempFile = os.tmpdir() + '/' + uuidv4() + '.jpg';
        let resizeArgs = {
            srcData: inputData.Body,
            dstPath: tempFile,
            width: 150
        };
        await resizeAsync(resizeArgs);

        // read the resized file
        let resizeData = await readFileAsync(tempFile);

        // upload to s3
        let targetFilename = filename.substring(0, filename.lastIndexof('.')) + '-small.jpg';
        var params = {
            Bucket: bucket + '-dest',
            Key: targetFilename,
            Body: new Buffer(resizedData),
            ContentType: 'image/jpeg'
        };

        await s3.putObject(params).promise();
        return await unlinkAsync(tempFile);

   });

   await Promise.all(filesProcessed);
   console.log("done");
   return "done";
}